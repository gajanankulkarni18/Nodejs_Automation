const puppeteer = require("puppeteer");

(async () => {
    const searchQuery = "sanket.tarde01@gmail.com"
    browser = await puppeteer.launch({headless: false});
    const [page] = await browser.pages();
    await page.goto("https://www.gmail.com/");
    await page.waitForSelector('#identifierId', {visible: true});
    await page.type('#identifierId', searchQuery);
    await Promise.all([
        page.waitForNavigation(),
        page.keyboard.press("Enter"),
    ]);

    await page.waitForSelector('//*[@id="password"]/div[1]/div/div[1]/input', {visible: true});
    await page.type('//*[@id="password"]/div[1]/div/div[1]/input', "9604660308@Sst");
    await Promise.all([
        page.waitForNavigation(),
        page.keyboard.press("Enter"),
    ]);
})()

    .catch(err => console.error(err))
    .finally(async() => await browser.close());