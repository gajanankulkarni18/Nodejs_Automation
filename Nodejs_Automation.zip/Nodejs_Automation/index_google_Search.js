const puppeteer = require("puppeteer");

(async () => {
    const searchQuery = "stack overflow"
    browser = await puppeteer.launch({headless: false});
    const [page] = await browser.pages();
    await page.goto("https://www.google.com/");
    await page.waitForSelector('input[aria-label="Search"]', {visible: true});
    await page.type('input[aria-label="Search"]', searchQuery);
    await Promise.all([
        page.waitForNavigation(),
        page.keyboard.press("Enter"),
    ]);

    await page.waitForSelector(".LC20lb", {visible: true});
    const searchResults = await page.evaluate(() => 
    [...document.querySelectorAll(".LC20lb")].map( e => ({
        title: e.innerText,
        link: e.parentNode.href
    })));
    console.log(result);
})()

    .catch(err => console.error(err))
    .finally(async() => await browser.close());