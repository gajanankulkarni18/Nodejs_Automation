const puppeteer = require("puppeteer");

(async () => {
  const browser = await puppeteer.launch({headless: false});
  const page = await browser.newPage();
  await page.goto("https://www.wikipedia.org/");
  await page.screenshot({
    path: 'example1.png',
    type: 'png',
    fullPage: true
  })
  
  await browser.close();
})();