const puppeteer = require("puppeteer");

(async () => {
    browser = await puppeteer.launch({headless: false});
    const [page] = await browser.pages();
    await page.goto("https://accounts.lambdatest.com/login");
    await page.waitForSelector('#email', {visible: true});
    await page.type('#email', "sanket.tarde01@gmail.com");
    await page.waitForSelector('#password', {visible: true});
    await page.type('#password', "9604660308@Sst");
    await Promise.all([
        page.waitForNavigation(),
        page.keyboard.press("Enter"),
    ]);
})()

    .catch(err => console.error(err))
    .finally(async() => await browser.close());